/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { LoginModal } from './components/LoginModal';
import { PosView } from './components/PosView';
import { HistoryView } from './components/HistoryView';
import { StockView } from './components/StockView';
import { SettingsView } from './components/SettingsView';
import { ReceiptModal } from './components/ReceiptModal';
import { PrintReceipt } from './components/PrintReceipt';
import {
  getCurrentUser,
  setCurrentUser,
  getStoreSettings,
  getVoucherPackages,
  getTransactions,
} from './services/storage';
import { CashierUser, StoreSettings, VoucherPackage, Transaction } from './types';
import { WifiOff, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [currentUser, setCachedUser] = useState<CashierUser | null>(() => getCurrentUser());
  const [settings, setSettings] = useState<StoreSettings>(() => getStoreSettings());
  const [packages, setPackages] = useState<VoucherPackage[]>(() => getVoucherPackages());
  const [transactions, setTransactions] = useState<Transaction[]>(() => getTransactions());

  const [currentTab, setCurrentTab] = useState<'pos' | 'history' | 'stock' | 'settings'>('pos');
  const [activeReceipt, setActiveReceipt] = useState<Transaction | null>(null);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  // Monitor network status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Register service worker if available
    if ('serviceWorker' in navigator && process.env.NODE_ENV !== 'development') {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const refreshTransactions = () => {
    setTransactions(getTransactions());
  };

  const handleLoginSuccess = (user: CashierUser) => {
    setCurrentUser(user);
    setCachedUser(user);
  };

  const handleLogout = () => {
    if (confirm('Kunci layar kasir & keluar sesi?')) {
      setCurrentUser(null);
      setCachedUser(null);
    }
  };

  const handleTransactionCompleted = (newTrx: Transaction) => {
    refreshTransactions();
    setActiveReceipt(newTrx);
    setIsReceiptOpen(true);
  };

  const handleSelectTransaction = (trx: Transaction) => {
    setActiveReceipt(trx);
    setIsReceiptOpen(true);
  };

  // Today count
  const todayTransactionsCount = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    return transactions.filter(
      (t) => new Date(t.createdAt).getTime() >= startOfToday
    ).length;
  }, [transactions]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Offline Status Pill Notification (If disconnected) */}
      {!isOnline && (
        <div className="bg-amber-600 text-slate-950 px-4 py-1.5 text-xs font-bold text-center flex items-center justify-center gap-2 shadow-sm">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Mode Offline Aktif - Kasir tetap berfungsi normal, semua data tersimpan di perangkat ini.</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        settings={settings}
        currentUser={currentUser}
        onLogout={handleLogout}
        todayCount={todayTransactionsCount}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {currentTab === 'pos' && (
          <PosView
            packages={packages}
            settings={settings}
            currentUser={currentUser}
            onTransactionCompleted={handleTransactionCompleted}
            onNavigateToStock={() => setCurrentTab('stock')}
          />
        )}

        {currentTab === 'history' && (
          <HistoryView
            transactions={transactions}
            settings={settings}
            onRefreshTransactions={refreshTransactions}
            onSelectTransaction={handleSelectTransaction}
          />
        )}

        {currentTab === 'stock' && (
          <StockView
            packages={packages}
            settings={settings}
            onStockUpdated={refreshTransactions}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsView
            settings={settings}
            packages={packages}
            currentUser={currentUser}
            onSettingsUpdated={(newSettings) => setSettings(newSettings)}
            onPackagesUpdated={(newPackages) => setPackages(newPackages)}
          />
        )}
      </main>

      {/* Cashier Login Screen (format awal menggunakan user & password) */}
      {!currentUser && (
        <LoginModal
          onLoginSuccess={handleLoginSuccess}
          storeName={settings.storeName}
        />
      )}

      {/* Receipt Modal (Print, WA, Download TXT, Copy) */}
      <ReceiptModal
        isOpen={isReceiptOpen}
        transaction={activeReceipt}
        settings={settings}
        onClose={() => setIsReceiptOpen(false)}
        onNewTransaction={() => {
          setIsReceiptOpen(false);
          setCurrentTab('pos');
        }}
      />

      {/* Dedicated Print Container for Thermal Printers (Standard 58mm / 80mm) */}
      <div id="thermal-receipt-print-wrapper">
        <PrintReceipt transaction={activeReceipt} settings={settings} />
      </div>
    </div>
  );
}
