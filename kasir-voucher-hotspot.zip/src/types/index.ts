export type PaymentMethod = 'tunai' | 'transfer';

export interface VoucherPackage {
  id: string;
  name: string;
  nominal: number;
  duration: string;
  price: number;
  description: string;
  color?: string;
}

export interface HotspotVoucher {
  id: string;
  packageId: string;
  packageName: string;
  username: string;
  password: string;
  isUsed: boolean;
  usedAt?: string;
  transactionId?: string;
  createdAt: string;
}

export interface TransactionItem {
  packageId: string;
  packageName: string;
  nominal: number;
  duration: string;
  price: number;
  quantity: number;
  vouchers: Array<{
    username: string;
    password: string;
  }>;
}

export interface Transaction {
  id: string; // e.g., TRX-20261027-001
  createdAt: string;
  cashierName: string;
  customerName?: string;
  customerPhone?: string;
  items: TransactionItem[];
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentDetail?: {
    cashReceived?: number;
    cashChange?: number;
    transferBank?: string;
    transferAccount?: string;
    transferRef?: string;
  };
  notes?: string;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  address: string;
  phone: string;
  wifiSsid: string;
  hotspotLoginUrl: string;
  footerMessage: string;
  printerPaperWidth: '58mm' | '80mm';
  transferBankName: string;
  transferAccountNumber: string;
  transferAccountHolder: string;
  qrisUrl?: string;
  voucherFormatPrefix: string;
  voucherUsernameLength: number;
  voucherPasswordLength: number;
  sameUserPass: boolean;
}

export interface CashierUser {
  id: string;
  username: string;
  name: string;
  role: 'admin' | 'kasir';
  passwordHash: string; // simple stored string for local offline app
}
