import { VoucherPackage, StoreSettings, CashierUser } from '../types';

/**
 * Paket voucher resmi sesuai instruksi pengguna:
 * 1. 1000  -> 5 Jam   -> Harga Jual Rp 800
 * 2. 2000  -> 12 Jam  -> Harga Jual Rp 1.500
 * 3. 3000  -> 24 Jam  -> Harga Jual Rp 2.500
 * 4. 5000  -> 2 Hari  -> Harga Jual Rp 4.000
 * 5. 15000 -> 7 Hari  -> Harga Jual Rp 13.000
 * 6. 25000 -> 15 Hari -> Harga Jual Rp 25.000
 * 7. 45000 -> 30 Hari -> Harga Jual Rp 45.000
 */
export const DEFAULT_VOUCHER_PACKAGES: VoucherPackage[] = [
  {
    id: 'pkg-1000-5h',
    name: '1.000 (5 Jam)',
    nominal: 1000,
    duration: '5 Jam',
    price: 800,
    description: 'Aktif 5 Jam Non-Stop',
    color: '#3b82f6', // blue
  },
  {
    id: 'pkg-2000-12h',
    name: '2.000 (12 Jam)',
    nominal: 2000,
    duration: '12 Jam',
    price: 1500,
    description: 'Aktif 12 Jam Seharian',
    color: '#06b6d4', // cyan
  },
  {
    id: 'pkg-3000-24h',
    name: '3.000 (24 Jam)',
    nominal: 3000,
    duration: '24 Jam',
    price: 2500,
    description: 'Aktif 1 Hari Penuh (24 Jam)',
    color: '#10b981', // emerald
  },
  {
    id: 'pkg-5000-2d',
    name: '5.000 (2 Hari)',
    nominal: 5000,
    duration: '2 Hari',
    price: 4000,
    description: 'Aktif 2 Hari',
    color: '#8b5cf6', // purple
  },
  {
    id: 'pkg-15000-7d',
    name: '15.000 (7 Hari)',
    nominal: 15000,
    duration: '7 Hari',
    price: 13000,
    description: 'Paket Hemat 1 Minggu (7 Hari)',
    color: '#f59e0b', // amber
  },
  {
    id: 'pkg-25000-15d',
    name: '25.000 (15 Hari)',
    nominal: 25000,
    duration: '15 Hari',
    price: 25000,
    description: 'Aktif Setengah Bulan (15 Hari)',
    color: '#ec4899', // pink
  },
  {
    id: 'pkg-45000-30d',
    name: '45.000 (30 Hari)',
    nominal: 45000,
    duration: '30 Hari',
    price: 45000,
    description: 'Paket Bulanan Super Hemat (30 Hari)',
    color: '#ef4444', // red
  },
];

export const DEFAULT_SETTINGS: StoreSettings = {
  storeName: 'KASIR HOTSPOT WIFI',
  tagline: 'Layanan Internet Cepat, Stabil & Hemat',
  address: 'Jl. Utama Hotspot No. 88, Samping Konter Pulsa',
  phone: '081234567890',
  wifiSsid: '@HOTSPOT-WIFI-ZONE',
  hotspotLoginUrl: 'http://hotspot.net',
  footerMessage: 'Simpan struk ini untuk login. Terima kasih telah berlangganan!',
  printerPaperWidth: '58mm',
  transferBankName: 'BCA / DANA / QRIS',
  transferAccountNumber: '123-456-7890 / 081234567890',
  transferAccountHolder: 'KURNIA HOTSPOT',
  voucherFormatPrefix: 'HS',
  voucherUsernameLength: 5,
  voucherPasswordLength: 4,
  sameUserPass: false,
};

export const DEFAULT_USERS: CashierUser[] = [
  {
    id: 'usr-admin',
    username: 'admin',
    name: 'Admin Kasir',
    role: 'admin',
    passwordHash: 'admin123',
  },
  {
    id: 'usr-kasir1',
    username: 'kasir',
    name: 'Kasir Shift 1',
    role: 'kasir',
    passwordHash: '123456',
  },
];
