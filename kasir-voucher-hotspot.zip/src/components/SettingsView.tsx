import React, { useState } from 'react';
import {
  Store,
  Wifi,
  CreditCard,
  Printer,
  Shield,
  Download,
  Upload,
  CheckCircle,
  Save,
  RotateCcw,
  KeyRound,
  Edit2,
  Trash2,
  Plus,
} from 'lucide-react';
import { StoreSettings, VoucherPackage, CashierUser } from '../types';
import {
  saveStoreSettings,
  saveVoucherPackages,
  resetVoucherPackages,
  getUsers,
  saveUsers,
  exportDatabaseBackup,
  importDatabaseBackup,
} from '../services/storage';
import { formatRupiah } from '../services/receiptFormatter';

interface SettingsViewProps {
  settings: StoreSettings;
  packages: VoucherPackage[];
  currentUser: CashierUser | null;
  onSettingsUpdated: (newSettings: StoreSettings) => void;
  onPackagesUpdated: (newPackages: VoucherPackage[]) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  packages,
  currentUser,
  onSettingsUpdated,
  onPackagesUpdated,
}) => {
  const [formData, setFormData] = useState<StoreSettings>({ ...settings });
  const [packageList, setPackageList] = useState<VoucherPackage[]>([...packages]);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Password change state
  const [newCashierPass, setNewCashierPass] = useState('');
  const [newAdminPass, setNewAdminPass] = useState('');
  const [passMessage, setPassMessage] = useState('');

  // Editing package price modal / inline
  const [editingPkgId, setEditingPkgId] = useState<string | null>(null);
  const [editingPrice, setEditingPrice] = useState<number>(0);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    saveStoreSettings(formData);
    onSettingsUpdated(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleResetPackages = () => {
    if (confirm('Kembalikan paket voucher ke harga resmi bawaan?')) {
      const reset = resetVoucherPackages();
      setPackageList(reset);
      onPackagesUpdated(reset);
    }
  };

  const handleUpdatePrice = (pkgId: string) => {
    const updated = packageList.map((p) =>
      p.id === pkgId ? { ...p, price: editingPrice } : p
    );
    setPackageList(updated);
    saveVoucherPackages(updated);
    onPackagesUpdated(updated);
    setEditingPkgId(null);
  };

  const handleChangePassword = (role: 'kasir' | 'admin') => {
    const users = getUsers();
    const newPass = role === 'kasir' ? newCashierPass : newAdminPass;

    if (!newPass.trim()) {
      alert('Password baru tidak boleh kosong!');
      return;
    }

    const updated = users.map((u) => {
      if (u.role === role) {
        return { ...u, passwordHash: newPass };
      }
      return u;
    });

    saveUsers(updated);
    if (role === 'kasir') setNewCashierPass('');
    if (role === 'admin') setNewAdminPass('');
    setPassMessage(`Password ${role} berhasil diperbarui!`);
    setTimeout(() => setPassMessage(''), 3000);
  };

  const handleDownloadBackup = () => {
    const jsonStr = exportDatabaseBackup();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Backup-Kasir-Hotspot-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const res = importDatabaseBackup(content);
        if (res.success) {
          alert('Data berhasil dipulihkan! Halaman akan memuat ulang.');
          window.location.reload();
        } else {
          alert(res.message);
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-5xl mx-auto p-3 sm:p-6 pb-24 md:pb-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-100">
            Pengaturan Aplikasi Kasir
          </h2>
          <p className="text-xs text-slate-400">
            Kustomisasi nama usaha hotspot, WiFi SSID, rekening bank, harga paket, dan backup
          </p>
        </div>

        {saveSuccess && (
          <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-3 py-1.5 rounded-lg">
            <CheckCircle className="w-4 h-4" />
            <span>Pengaturan tersimpan!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* 1. STORE PROFILE */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 space-y-4 shadow-xl">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Store className="w-5 h-5 text-blue-400" />
            <h3 className="font-bold text-sm text-slate-100">Profil Usaha Hotspot</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Nama Usaha / Hotspot
              </label>
              <input
                type="text"
                value={formData.storeName}
                onChange={(e) => setFormData({ ...formData, storeName: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Slogan / Tagline
              </label>
              <input
                type="text"
                value={formData.tagline}
                onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Alamat / Lokasi Toko
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Nomor Telp / WhatsApp CS
              </label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        </div>

        {/* 2. HOTSPOT & RECEIPT SETTINGS */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 space-y-4 shadow-xl">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Wifi className="w-5 h-5 text-blue-400" />
            <h3 className="font-bold text-sm text-slate-100">Pengaturan Jaringan WiFi & Struk</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Nama Sinyal WiFi (SSID)
              </label>
              <input
                type="text"
                value={formData.wifiSsid}
                onChange={(e) => setFormData({ ...formData, wifiSsid: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500 font-mono"
              />
              <p className="text-[10px] text-slate-500 mt-1">Dicetak pada instruksi struk</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Alamat Login Hotspot URL
              </label>
              <input
                type="text"
                value={formData.hotspotLoginUrl}
                onChange={(e) => setFormData({ ...formData, hotspotLoginUrl: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500 font-mono"
              />
              <p className="text-[10px] text-slate-500 mt-1">Contoh: http://hotspot.net atau 192.168.1.1</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Ukuran Lebar Kertas Struk
              </label>
              <select
                value={formData.printerPaperWidth}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    printerPaperWidth: e.target.value as '58mm' | '80mm',
                  })
                }
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              >
                <option value="58mm">58mm (Printer Kasir Mini Thermal Bluetooth / USB)</option>
                <option value="80mm">80mm (Printer Kasir Standar POS)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Pesan Footer Struk
              </label>
              <input
                type="text"
                value={formData.footerMessage}
                onChange={(e) => setFormData({ ...formData, footerMessage: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        </div>

        {/* 3. REKENING TRANSFER / NON-TUNAI */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 space-y-4 shadow-xl">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <CreditCard className="w-5 h-5 text-blue-400" />
            <h3 className="font-bold text-sm text-slate-100">Rekening Tujuan Pembayaran Transfer</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Nama Bank / E-Wallet
              </label>
              <input
                type="text"
                value={formData.transferBankName}
                onChange={(e) => setFormData({ ...formData, transferBankName: e.target.value })}
                placeholder="BCA / BRI / DANA / QRIS"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Nomor Rekening / No. HP
              </label>
              <input
                type="text"
                value={formData.transferAccountNumber}
                onChange={(e) => setFormData({ ...formData, transferAccountNumber: e.target.value })}
                placeholder="1234-5678-90"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Atas Nama (Pemilik)
              </label>
              <input
                type="text"
                value={formData.transferAccountHolder}
                onChange={(e) => setFormData({ ...formData, transferAccountHolder: e.target.value })}
                placeholder="Kurnia Hotspot"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        </div>

        {/* SAVE BUTTON */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="py-3 px-6 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-lg shadow-blue-600/30 flex items-center gap-2 cursor-pointer transition-all"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Perubahan Pengaturan</span>
          </button>
        </div>
      </form>

      {/* 4. VOUCHER PACKAGES PRICE MANAGER */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="font-bold text-sm text-slate-100">Daftar & Harga Jual Paket Voucher</h3>
            <p className="text-xs text-slate-400">
              Ubah harga jual voucher jika terjadi perubahan tarif
            </p>
          </div>

          <button
            type="button"
            onClick={handleResetPackages}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset ke Bawaan</span>
          </button>
        </div>

        <div className="divide-y divide-slate-800/80">
          {packageList.map((pkg) => (
            <div
              key={pkg.id}
              className="py-3 flex items-center justify-between gap-3 text-xs"
            >
              <div>
                <span className="font-bold text-slate-100">{pkg.name}</span>
                <span className="text-slate-500 ml-2">Durasi: {pkg.duration}</span>
              </div>

              <div className="flex items-center gap-3">
                {editingPkgId === pkg.id ? (
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={editingPrice}
                      onChange={(e) => setEditingPrice(parseInt(e.target.value) || 0)}
                      className="w-28 px-2 py-1 bg-slate-950 border border-blue-500 rounded text-slate-100 font-mono text-xs"
                      autoFocus
                    />
                    <button
                      onClick={() => handleUpdatePrice(pkg.id)}
                      className="px-2.5 py-1 bg-emerald-600 text-white rounded text-xs font-semibold"
                    >
                      OK
                    </button>
                    <button
                      onClick={() => setEditingPkgId(null)}
                      className="px-2 py-1 bg-slate-800 text-slate-300 rounded text-xs"
                    >
                      Batal
                    </button>
                  </div>
                ) : (
                  <>
                    <span className="font-bold font-mono text-emerald-400 text-sm">
                      {formatRupiah(pkg.price)}
                    </span>
                    <button
                      onClick={() => {
                        setEditingPkgId(pkg.id);
                        setEditingPrice(pkg.price);
                      }}
                      className="p-1.5 text-slate-400 hover:text-blue-400 rounded hover:bg-slate-800 transition-colors"
                      title="Ubah Harga"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. USER & PASSWORD CASHIER SECURITY */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <KeyRound className="w-5 h-5 text-blue-400" />
          <h3 className="font-bold text-sm text-slate-100">Ganti Password Login Kasir</h3>
        </div>

        {passMessage && (
          <div className="p-2.5 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs">
            {passMessage}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <div className="font-bold text-xs text-slate-200">Ganti Password Kasir (Shift)</div>
            <div className="text-[11px] text-slate-400">Username: <code className="text-blue-400">kasir</code></div>
            <div className="flex gap-2">
              <input
                type="password"
                value={newCashierPass}
                onChange={(e) => setNewCashierPass(e.target.value)}
                placeholder="Password baru kasir..."
                className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              />
              <button
                type="button"
                onClick={() => handleChangePassword('kasir')}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
              >
                Ubah
              </button>
            </div>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <div className="font-bold text-xs text-slate-200">Ganti Password Admin</div>
            <div className="text-[11px] text-slate-400">Username: <code className="text-blue-400">admin</code></div>
            <div className="flex gap-2">
              <input
                type="password"
                value={newAdminPass}
                onChange={(e) => setNewAdminPass(e.target.value)}
                placeholder="Password baru admin..."
                className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              />
              <button
                type="button"
                onClick={() => handleChangePassword('admin')}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
              >
                Ubah
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 6. OFFLINE DATA BACKUP & RESTORE */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <Shield className="w-5 h-5 text-blue-400" />
          <h3 className="font-bold text-sm text-slate-100">Cadangkan & Pulihkan Data Kasir (Offline)</h3>
        </div>

        <p className="text-xs text-slate-400">
          Semua transaksi, pengaturan, dan stok voucher tersimpan di memori perangkat ini. Anda dapat mengunduh file cadangan (.json) kapan saja untuk keamanan atau dipindahkan ke PC / HP lain.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            type="button"
            onClick={handleDownloadBackup}
            className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-blue-400" />
            <span>Unduh Cadangan (Backup Data JSON)</span>
          </button>

          <label className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition-colors cursor-pointer">
            <Upload className="w-4 h-4 text-emerald-400" />
            <span>Pulihkan dari File Backup</span>
            <input
              type="file"
              accept=".json"
              onChange={handleImportBackup}
              className="hidden"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
