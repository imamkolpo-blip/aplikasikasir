import React from 'react';
import { Transaction, StoreSettings } from '../types';
import { formatRupiah, formatDateTime } from '../services/receiptFormatter';

interface PrintReceiptProps {
  transaction: Transaction | null;
  settings: StoreSettings;
}

export const PrintReceipt: React.FC<PrintReceiptProps> = ({ transaction, settings }) => {
  if (!transaction) return null;

  const is58 = settings.printerPaperWidth === '58mm';
  const widthClass = is58 ? 'w-[58mm] max-w-[58mm]' : 'w-[80mm] max-w-[80mm]';

  return (
    <div
      id="thermal-receipt-print"
      className={`${widthClass} mx-auto bg-white text-black font-mono text-[11px] leading-tight p-3 sm:p-4`}
    >
      {/* Header */}
      <div className="text-center mb-2 pb-1 border-b border-dashed border-black">
        <h2 className="text-sm font-black uppercase tracking-wider">{settings.storeName}</h2>
        {settings.tagline && <p className="text-[10px] italic mt-0.5">{settings.tagline}</p>}
        {settings.address && <p className="text-[9px] mt-0.5">{settings.address}</p>}
        {settings.phone && <p className="text-[9px]">Telp/WA: {settings.phone}</p>}
      </div>

      {/* Meta Info */}
      <div className="text-[10px] space-y-0.5 mb-2 pb-2 border-b border-dashed border-black">
        <div className="flex justify-between">
          <span>NO. TRX</span>
          <span className="font-bold">{transaction.id}</span>
        </div>
        <div className="flex justify-between">
          <span>WAKTU</span>
          <span>{formatDateTime(transaction.createdAt)}</span>
        </div>
        <div className="flex justify-between">
          <span>KASIR</span>
          <span>{transaction.cashierName}</span>
        </div>
        {transaction.customerName && (
          <div className="flex justify-between">
            <span>PELANGGAN</span>
            <span className="font-semibold">{transaction.customerName}</span>
          </div>
        )}
        <div className="flex justify-between">
          <span>PEMBAYARAN</span>
          <span className="font-bold uppercase">
            {transaction.paymentMethod === 'tunai' ? 'TUNAI' : 'TRANSFER'}
          </span>
        </div>
      </div>

      {/* Item List */}
      <div className="mb-2 pb-2 border-b border-dashed border-black">
        <div className="font-bold text-[10px] mb-1">DETAIL PESANAN:</div>
        {transaction.items.map((item, idx) => (
          <div key={idx} className="mb-1.5">
            <div className="flex justify-between font-bold">
              <span>{item.packageName}</span>
              <span>{formatRupiah(item.price * item.quantity)}</span>
            </div>
            <div className="text-[9px] text-gray-700 flex justify-between">
              <span>Durasi: {item.duration}</span>
              <span>{item.quantity} x {formatRupiah(item.price)}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Hotspot Credentials Highlight Box */}
      <div className="mb-3 p-2 bg-gray-100 border-2 border-black rounded text-center">
        <div className="font-black text-[11px] uppercase tracking-wider text-black border-b border-black pb-1 mb-1.5">
          AKUN LOGIN HOTSPOT
        </div>
        {transaction.items.flatMap((item) => item.vouchers).map((vch, vIdx) => (
          <div key={vIdx} className="mb-2 last:mb-0 bg-white p-1.5 border border-dashed border-gray-400 rounded">
            <div className="text-[9px] text-gray-600 font-bold mb-0.5">VOUCHER #{vIdx + 1}</div>
            <div className="flex justify-between text-xs py-0.5">
              <span className="font-bold text-gray-700">USER:</span>
              <span className="font-black text-sm tracking-wider select-all">{vch.username}</span>
            </div>
            <div className="flex justify-between text-xs py-0.5 border-t border-dotted border-gray-300">
              <span className="font-bold text-gray-700">PASS:</span>
              <span className="font-black text-sm tracking-wider select-all">{vch.password}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Payment Summary */}
      <div className="text-[10px] space-y-1 mb-2 pb-2 border-b border-dashed border-black">
        <div className="flex justify-between text-xs font-black">
          <span>TOTAL BAYAR</span>
          <span>{formatRupiah(transaction.totalAmount)}</span>
        </div>

        {transaction.paymentMethod === 'tunai' && transaction.paymentDetail?.cashReceived && (
          <>
            <div className="flex justify-between text-[10px]">
              <span>BAYAR TUNAI</span>
              <span>{formatRupiah(transaction.paymentDetail.cashReceived)}</span>
            </div>
            <div className="flex justify-between text-[10px] font-bold">
              <span>KEMBALIAN</span>
              <span>{formatRupiah(transaction.paymentDetail.cashChange || 0)}</span>
            </div>
          </>
        )}

        {transaction.paymentMethod === 'transfer' && (
          <div className="text-[9px] text-gray-700">
            <div>Bank/Tujuan: {transaction.paymentDetail?.transferBank || settings.transferBankName}</div>
            {transaction.paymentDetail?.transferRef && (
              <div>Ref: {transaction.paymentDetail.transferRef}</div>
            )}
          </div>
        )}
      </div>

      {/* Instructions */}
      <div className="text-[9px] space-y-0.5 mb-2 text-center">
        <p className="font-bold">CARA LOGIN INTERNET:</p>
        <p>1. Hubungkan WiFi ke: <span className="font-bold">{settings.wifiSsid}</span></p>
        <p>2. Buka browser: <span className="font-bold">{settings.hotspotLoginUrl}</span></p>
        <p>3. Masukkan USER & PASS di atas lalu klik Login</p>
      </div>

      {/* Footer */}
      <div className="text-center text-[8px] text-gray-700 pt-1 border-t border-dashed border-black">
        <p>{settings.footerMessage}</p>
        <p className="mt-1 font-mono tracking-widest text-[7px] text-gray-500">
          *** TERIMA KASIH ***
        </p>
      </div>
    </div>
  );
};
