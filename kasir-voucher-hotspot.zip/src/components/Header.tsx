import React, { useState, useEffect } from 'react';
import {
  Wifi,
  Receipt,
  History,
  Layers,
  Settings,
  LogOut,
  User,
  Clock,
  WifiOff,
  CheckCircle2,
} from 'lucide-react';
import { StoreSettings, CashierUser } from '../types';

interface HeaderProps {
  currentTab: 'pos' | 'history' | 'stock' | 'settings';
  setCurrentTab: (tab: 'pos' | 'history' | 'stock' | 'settings') => void;
  settings: StoreSettings;
  currentUser: CashierUser | null;
  onLogout: () => void;
  todayCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  settings,
  currentUser,
  onLogout,
  todayCount,
}) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      clearInterval(timer);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Brand & WiFi Info */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/20 shrink-0">
              <Wifi className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-base sm:text-lg tracking-tight text-white leading-tight">
                  {settings.storeName || 'KASIR HOTSPOT'}
                </h1>
                <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.5 rounded-md">
                  <CheckCircle2 className="w-3 h-3" /> Offline OK
                </span>
              </div>
              <div className="text-xs text-slate-400 flex items-center gap-2">
                <span className="text-blue-400 font-mono font-medium truncate max-w-[150px] sm:max-w-none">
                  SSID: {settings.wifiSsid}
                </span>
                <span className="hidden md:inline text-slate-600">|</span>
                <span className="hidden md:inline text-slate-400">
                  {settings.hotspotLoginUrl}
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Tabs (Desktop & Tablet) */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800/80">
            <button
              onClick={() => setCurrentTab('pos')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                currentTab === 'pos'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Receipt className="w-4 h-4" />
              <span>Kasir (POS)</span>
            </button>

            <button
              onClick={() => setCurrentTab('history')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all relative ${
                currentTab === 'history'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Riwayat Transaksi</span>
              {todayCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 bg-blue-500 text-white text-[10px] rounded-full font-bold">
                  {todayCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setCurrentTab('stock')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                currentTab === 'stock'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Stok Voucher</span>
            </button>

            <button
              onClick={() => setCurrentTab('settings')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                currentTab === 'settings'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Pengaturan</span>
            </button>
          </nav>

          {/* Right Section: Time, Cashier User & Logout */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="hidden lg:flex items-center gap-1.5 text-xs text-slate-400 font-mono bg-slate-950/60 px-2.5 py-1.5 rounded-lg border border-slate-800">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>{timeStr}</span>
            </div>

            {currentUser && (
              <div className="flex items-center gap-2 bg-slate-800/80 hover:bg-slate-800 px-2.5 py-1.5 rounded-lg border border-slate-700/80 text-xs">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
                  <User className="w-3.5 h-3.5" />
                </div>
                <div className="text-left hidden sm:block">
                  <p className="font-semibold text-slate-200 leading-tight">
                    {currentUser.name}
                  </p>
                  <p className="text-[10px] text-slate-400 capitalize">
                    {currentUser.role}
                  </p>
                </div>
                <button
                  onClick={onLogout}
                  title="Kunci / Keluar Akun Kasir"
                  className="ml-1 p-1 text-slate-400 hover:text-rose-400 rounded transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Nav for Mobile Screens */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-800 bg-slate-950/95 py-2 px-1">
        <button
          onClick={() => setCurrentTab('pos')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg text-[11px] font-medium transition-colors ${
            currentTab === 'pos' ? 'text-blue-400' : 'text-slate-400'
          }`}
        >
          <Receipt className="w-5 h-5" />
          <span>Kasir</span>
        </button>

        <button
          onClick={() => setCurrentTab('history')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg text-[11px] font-medium transition-colors relative ${
            currentTab === 'history' ? 'text-blue-400' : 'text-slate-400'
          }`}
        >
          <History className="w-5 h-5" />
          <span>Riwayat</span>
          {todayCount > 0 && (
            <span className="absolute top-0 right-2 w-2 h-2 rounded-full bg-blue-500" />
          )}
        </button>

        <button
          onClick={() => setCurrentTab('stock')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg text-[11px] font-medium transition-colors ${
            currentTab === 'stock' ? 'text-blue-400' : 'text-slate-400'
          }`}
        >
          <Layers className="w-5 h-5" />
          <span>Stok</span>
        </button>

        <button
          onClick={() => setCurrentTab('settings')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg text-[11px] font-medium transition-colors ${
            currentTab === 'settings' ? 'text-blue-400' : 'text-slate-400'
          }`}
        >
          <Settings className="w-5 h-5" />
          <span>Pengaturan</span>
        </button>
      </div>
    </header>
  );
};
