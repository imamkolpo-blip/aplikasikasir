import React, { useState } from 'react';
import {
  Printer,
  Share2,
  Download,
  Copy,
  Check,
  X,
  Send,
  FileText,
  Sparkles,
  Phone,
} from 'lucide-react';
import { Transaction, StoreSettings } from '../types';
import { PrintReceipt } from './PrintReceipt';
import {
  generateWhatsAppUrl,
  buildPlainTextReceipt,
  buildWhatsAppMessage,
} from '../services/receiptFormatter';

interface ReceiptModalProps {
  transaction: Transaction | null;
  settings: StoreSettings;
  isOpen: boolean;
  onClose: () => void;
  onNewTransaction?: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  transaction,
  settings,
  isOpen,
  onClose,
  onNewTransaction,
}) => {
  const [copied, setCopied] = useState(false);
  const [waPhone, setWaPhone] = useState(transaction?.customerPhone || '');
  const [showPhoneInput, setShowPhoneInput] = useState(false);

  if (!isOpen || !transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleCopyText = async () => {
    const text = buildPlainTextReceipt(transaction, settings);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
    }
  };

  const handleShareWA = () => {
    const url = generateWhatsAppUrl(transaction, settings, waPhone);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleDownloadTxt = () => {
    const text = buildPlainTextReceipt(transaction, settings);
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Struk-${transaction.id}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in duration-150">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-100">Struk Pembelian Berhasil</h3>
              <p className="text-[11px] text-slate-400">ID: {transaction.id}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Buttons Toolbar */}
        <div className="p-4 bg-slate-950/80 border-b border-slate-800/80 space-y-3">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {/* Print Button */}
            <button
              onClick={handlePrint}
              className="flex items-center justify-center gap-2 py-2.5 px-3 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-md shadow-blue-600/20 transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print Struk</span>
            </button>

            {/* WhatsApp Share Button */}
            <button
              onClick={() => {
                if (!transaction.customerPhone && !showPhoneInput) {
                  setShowPhoneInput(true);
                } else {
                  handleShareWA();
                }
              }}
              className="flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              <span>Kirim WA</span>
            </button>

            {/* Download Text Slip */}
            <button
              onClick={handleDownloadTxt}
              className="flex items-center justify-center gap-2 py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium border border-slate-700 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-400" />
              <span>Simpan File</span>
            </button>

            {/* Copy Text */}
            <button
              onClick={handleCopyText}
              className="flex items-center justify-center gap-2 py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium border border-slate-700 transition-all cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400 font-semibold">Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-400" />
                  <span>Salin Teks</span>
                </>
              )}
            </button>
          </div>

          {/* Quick WhatsApp Phone prompt if not filled */}
          {showPhoneInput && (
            <div className="p-2.5 bg-slate-900 border border-emerald-500/30 rounded-xl flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
              <input
                type="tel"
                value={waPhone}
                onChange={(e) => setWaPhone(e.target.value)}
                placeholder="Nomor WhatsApp (contoh: 08123456789)..."
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={handleShareWA}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Kirim</span>
              </button>
            </div>
          )}
        </div>

        {/* Receipt Visual Container (Thermal Preview) */}
        <div className="p-4 sm:p-6 max-h-[55vh] overflow-y-auto bg-slate-900/60 flex justify-center">
          <div className="shadow-2xl rounded-sm border border-slate-300 transform scale-95 origin-top transition-transform">
            <PrintReceipt transaction={transaction} settings={settings} />
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="flex items-center justify-between p-4 bg-slate-950 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
          >
            Tutup
          </button>

          {onNewTransaction && (
            <button
              onClick={() => {
                onClose();
                onNewTransaction();
              }}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-xl shadow transition-colors"
            >
              + Transaksi Baru
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
