import React, { useState, useMemo } from 'react';
import {
  Plus,
  Minus,
  Trash2,
  Clock,
  Wifi,
  Wallet,
  CreditCard,
  User,
  Phone,
  Sparkles,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Database,
  RefreshCw,
  QrCode,
  Tag,
} from 'lucide-react';
import {
  VoucherPackage,
  StoreSettings,
  Transaction,
  CashierUser,
  PaymentMethod,
} from '../types';
import { formatRupiah } from '../services/receiptFormatter';
import {
  generateVoucherCredentials,
  generateTransactionId,
} from '../services/voucherGenerator';
import {
  saveTransaction,
  consumeVoucherFromStock,
  getVoucherStock,
} from '../services/storage';

interface CartItem {
  package: VoucherPackage;
  quantity: number;
}

interface PosViewProps {
  packages: VoucherPackage[];
  settings: StoreSettings;
  currentUser: CashierUser | null;
  onTransactionCompleted: (trx: Transaction) => void;
  onNavigateToStock: () => void;
}

export const PosView: React.FC<PosViewProps> = ({
  packages,
  settings,
  currentUser,
  onTransactionCompleted,
  onNavigateToStock,
}) => {
  // Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('tunai');

  // Cash payment state
  const [cashReceived, setCashReceived] = useState<string>('');

  // Transfer payment state
  const [transferBank, setTransferBank] = useState<string>('BCA');
  const [transferRef, setTransferRef] = useState<string>('');

  // Voucher generation mode
  const [useStockOnly, setUseStockOnly] = useState<boolean>(false);

  // Stock inventory counts
  const stockInventory = useMemo(() => {
    const allStock = getVoucherStock();
    const counts: Record<string, number> = {};
    packages.forEach((pkg) => {
      counts[pkg.id] = allStock.filter(
        (v) => v.packageId === pkg.id && !v.isUsed
      ).length;
    });
    return counts;
  }, [packages, cart]);

  // Calculations
  const totalAmount = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.package.price * item.quantity, 0);
  }, [cart]);

  const numCashReceived = parseFloat(cashReceived) || 0;
  const cashChange = numCashReceived - totalAmount;
  const isCashSufficient = paymentMethod === 'tunai' ? numCashReceived >= totalAmount : true;

  // Add item to cart
  const handleAddToCart = (pkg: VoucherPackage) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.package.id === pkg.id);
      if (existing) {
        return prev.map((item) =>
          item.package.id === pkg.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { package: pkg, quantity: 1 }];
    });
  };

  // Stepper controls
  const handleUpdateQuantity = (packageId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.package.id === packageId) {
            const nextQty = item.quantity + delta;
            return nextQty > 0 ? { ...item, quantity: nextQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (packageId: string) => {
    setCart((prev) => prev.filter((item) => item.package.id !== packageId));
  };

  const handleClearCart = () => {
    setCart([]);
    setCashReceived('');
    setCustomerName('');
    setCustomerPhone('');
  };

  // Quick cash buttons
  const handleQuickCash = (amount: number) => {
    setCashReceived(String(amount));
  };

  // Submit Transaction
  const handleCheckout = () => {
    if (cart.length === 0) return;
    if (paymentMethod === 'tunai' && !isCashSufficient) {
      alert('Nominal uang tunai yang diterima masih kurang!');
      return;
    }

    // Generate or consume vouchers for each item
    const transactionItems = cart.map((cartItem) => {
      let itemVouchers: Array<{ username: string; password: string }> = [];

      // If user chose stock mode or stock exists
      if (useStockOnly) {
        const consumed = consumeVoucherFromStock(cartItem.package.id, cartItem.quantity);
        itemVouchers.push(...consumed);

        // If stock ran out, fallback to auto-generate the remainder
        const remainingQty = cartItem.quantity - consumed.length;
        for (let i = 0; i < remainingQty; i++) {
          itemVouchers.push(
            generateVoucherCredentials(settings, cartItem.package.duration)
          );
        }
      } else {
        // Auto generate on the fly
        for (let i = 0; i < cartItem.quantity; i++) {
          itemVouchers.push(
            generateVoucherCredentials(settings, cartItem.package.duration)
          );
        }
      }

      return {
        packageId: cartItem.package.id,
        packageName: cartItem.package.name,
        nominal: cartItem.package.nominal,
        duration: cartItem.package.duration,
        price: cartItem.package.price,
        quantity: cartItem.quantity,
        vouchers: itemVouchers,
      };
    });

    const newTransaction: Transaction = {
      id: generateTransactionId(),
      createdAt: new Date().toISOString(),
      cashierName: currentUser?.name || 'Kasir Hotspot',
      customerName: customerName.trim() || undefined,
      customerPhone: customerPhone.trim() || undefined,
      items: transactionItems,
      totalAmount,
      paymentMethod,
      paymentDetail:
        paymentMethod === 'tunai'
          ? {
              cashReceived: numCashReceived,
              cashChange: Math.max(0, cashChange),
            }
          : {
              transferBank,
              transferAccount: settings.transferAccountNumber,
              transferRef: transferRef.trim() || undefined,
            },
    };

    // Save to persistent local storage
    saveTransaction(newTransaction);

    // Callback to open receipt modal & update stats
    onTransactionCompleted(newTransaction);

    // Reset current sale
    handleClearCart();
  };

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 pb-24 md:pb-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* LEFT COLUMN: VOUCHER PACKAGES CATALOG (7 Cols) */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
                <span>Pilih Voucher Hotspot</span>
                <span className="text-xs text-slate-400 font-normal">
                  ({packages.length} Paket Tersedia)
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Klik kartu voucher untuk menambah ke keranjang belanja
              </p>
            </div>

            {/* Stock switch or reminder */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setUseStockOnly(!useStockOnly)}
                className={`text-[11px] font-medium px-2.5 py-1.5 rounded-lg border transition-colors flex items-center gap-1.5 cursor-pointer ${
                  useStockOnly
                    ? 'bg-blue-600/20 border-blue-500/50 text-blue-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
                title="Gunakan voucher yang diimpor dari stok jika ada"
              >
                <Database className="w-3.5 h-3.5" />
                <span>{useStockOnly ? 'Pakai Stok Tersimpan' : 'Auto-Generate User/Pass'}</span>
              </button>
            </div>
          </div>

          {/* Grid of Voucher Packages */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
            {packages.map((pkg) => {
              const inCart = cart.find((i) => i.package.id === pkg.id);
              const stockCount = stockInventory[pkg.id] || 0;

              return (
                <div
                  key={pkg.id}
                  onClick={() => handleAddToCart(pkg)}
                  className={`group relative p-4 rounded-xl border transition-all cursor-pointer select-none text-left flex flex-col justify-between ${
                    inCart
                      ? 'bg-blue-950/40 border-blue-500/70 shadow-lg shadow-blue-950/50 ring-1 ring-blue-500/50'
                      : 'bg-slate-900 hover:bg-slate-850 border-slate-800 hover:border-slate-700 shadow-sm'
                  }`}
                >
                  {/* Top Bar with Duration Tag */}
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                        <Clock className="w-3 h-3" />
                        <span>{pkg.duration}</span>
                      </span>

                      {/* In-cart badge or stock badge */}
                      {inCart ? (
                        <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs font-bold flex items-center justify-center shadow">
                          {inCart.quantity}
                        </span>
                      ) : useStockOnly ? (
                        <span className="text-[10px] text-slate-400 font-mono">
                          Stok: {stockCount}
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-500 font-mono">
                          Nominal {pkg.nominal.toLocaleString('id-ID')}
                        </span>
                      )}
                    </div>

                    {/* Voucher Name & Description */}
                    <h3 className="font-bold text-slate-100 text-base leading-tight group-hover:text-blue-400 transition-colors">
                      {pkg.name}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-1">
                      {pkg.description || `Masa aktif voucher ${pkg.duration}`}
                    </p>
                  </div>

                  {/* Price & Add Indicator */}
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                        Harga Jual
                      </div>
                      <div className="text-base font-extrabold text-emerald-400 font-mono">
                        {formatRupiah(pkg.price)}
                      </div>
                    </div>

                    <div className="w-8 h-8 rounded-lg bg-slate-800 group-hover:bg-blue-600 group-hover:text-white text-slate-300 flex items-center justify-center transition-colors">
                      <Plus className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Notice about Hotspot Login Format */}
          <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl text-xs text-slate-400 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Wifi className="w-4 h-4 text-blue-400 shrink-0" />
              <span>
                Format voucher: <strong className="text-slate-200">Username & Password</strong> otomatis dibuatkan & tertera jelas di struk.
              </span>
            </div>
            <button
              onClick={onNavigateToStock}
              className="text-blue-400 hover:text-blue-300 font-medium text-[11px] underline shrink-0 ml-2"
            >
              Kelola Stok Voucher →
            </button>
          </div>
        </div>

        {/* RIGHT COLUMN: CART & CHECKOUT (5 Cols) */}
        <div className="lg:col-span-5 xl:col-span-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden flex flex-col">
            {/* Cart Header */}
            <div className="p-4 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                  <span>Keranjang Penjualan</span>
                  {cart.length > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-blue-600 text-white text-[10px] font-bold">
                      {cart.reduce((s, i) => s + i.quantity, 0)} item
                    </span>
                  )}
                </h3>
              </div>
              {cart.length > 0 && (
                <button
                  onClick={handleClearCart}
                  className="text-xs text-rose-400 hover:text-rose-300 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>
              )}
            </div>

            {/* Cart Item List */}
            <div className="p-4 space-y-2.5 max-h-56 overflow-y-auto">
              {cart.length === 0 ? (
                <div className="py-8 text-center text-slate-500">
                  <Tag className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-400" />
                  <p className="text-xs">Keranjang masih kosong</p>
                  <p className="text-[11px] text-slate-600 mt-0.5">
                    Pilih paket voucher di sebelah kiri
                  </p>
                </div>
              ) : (
                cart.map((item) => (
                  <div
                    key={item.package.id}
                    className="p-2.5 bg-slate-950/60 border border-slate-800/80 rounded-xl flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-xs text-slate-200 truncate">
                        {item.package.name}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {formatRupiah(item.package.price)} / voucher
                      </div>
                    </div>

                    {/* Stepper */}
                    <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg p-0.5">
                      <button
                        onClick={() => handleUpdateQuantity(item.package.id, -1)}
                        className="w-6 h-6 rounded flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-7 text-center text-xs font-bold text-slate-200 font-mono">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => handleUpdateQuantity(item.package.id, 1)}
                        className="w-6 h-6 rounded flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Subtotal */}
                    <div className="text-right w-20">
                      <div className="text-xs font-bold text-slate-100 font-mono">
                        {formatRupiah(item.package.price * item.quantity)}
                      </div>
                    </div>

                    <button
                      onClick={() => handleRemoveItem(item.package.id)}
                      className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* Customer Inputs (Optional) */}
            <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-950/30 space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-500">
                    <User className="w-3.5 h-3.5" />
                  </div>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Nama Pelanggan (opsional)"
                    className="w-full pl-8 pr-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-500">
                    <Phone className="w-3.5 h-3.5" />
                  </div>
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="No. WA (0812...)"
                    className="w-full pl-8 pr-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="p-4 border-t border-slate-800 space-y-3">
              <label className="block text-xs font-semibold text-slate-300">
                Metode Pembayaran
              </label>

              {/* Segmented Control: Tunai vs Transfer */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('tunai')}
                  className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    paymentMethod === 'tunai'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Wallet className="w-4 h-4" />
                  <span>Tunai (Cash)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('transfer')}
                  className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    paymentMethod === 'transfer'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Transfer / QRIS</span>
                </button>
              </div>

              {/* Payment Details: TUNAI */}
              {paymentMethod === 'tunai' && (
                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Uang Diterima:</span>
                    {totalAmount > 0 && (
                      <button
                        type="button"
                        onClick={() => handleQuickCash(totalAmount)}
                        className="text-blue-400 hover:underline text-[11px] font-semibold"
                      >
                        Uang Pas ({formatRupiah(totalAmount)})
                      </button>
                    )}
                  </div>

                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center font-bold text-xs text-slate-500">
                      Rp
                    </span>
                    <input
                      type="number"
                      value={cashReceived}
                      onChange={(e) => setCashReceived(e.target.value)}
                      placeholder="0"
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 font-mono text-sm font-bold focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  {/* Preset Money Chips */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {[2000, 5000, 10000, 20000, 50000, 100000].map((nominal) => (
                      <button
                        key={nominal}
                        type="button"
                        onClick={() => handleQuickCash(nominal)}
                        className="px-2 py-1 rounded-md bg-slate-950 hover:bg-slate-800 border border-slate-800 text-[10px] font-mono text-slate-300 transition-colors"
                      >
                        {nominal >= 1000 ? `${nominal / 1000}k` : nominal}
                      </button>
                    ))}
                  </div>

                  {/* Kembalian Calculation */}
                  {numCashReceived > 0 && (
                    <div
                      className={`p-2.5 rounded-xl border flex items-center justify-between text-xs font-mono transition-colors ${
                        isCashSufficient
                          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                          : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                      }`}
                    >
                      <span className="font-semibold">
                        {isCashSufficient ? 'Kembalian:' : 'Uang Kurang:'}
                      </span>
                      <span className="text-sm font-extrabold">
                        {formatRupiah(Math.abs(cashChange))}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Payment Details: TRANSFER */}
              {paymentMethod === 'transfer' && (
                <div className="space-y-2 pt-1 text-xs">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      Pilih Tujuan Transfer / E-Wallet:
                    </label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {['BCA', 'BRI', 'Mandiri', 'QRIS', 'DANA', 'GoPay'].map((bank) => (
                        <button
                          key={bank}
                          type="button"
                          onClick={() => setTransferBank(bank)}
                          className={`py-1.5 px-2 rounded-lg border text-center font-bold text-xs transition-colors ${
                            transferBank === bank
                              ? 'bg-blue-600/30 border-blue-500 text-blue-300'
                              : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          {bank}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Store account info reminder */}
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] space-y-0.5">
                    <div className="text-slate-400">Rekening Tujuan Toko:</div>
                    <div className="font-bold text-slate-200 font-mono">
                      {settings.transferAccountNumber || 'Belum diatur di Pengaturan'}
                    </div>
                    <div className="text-[10px] text-slate-500">
                      a.n {settings.transferAccountHolder || settings.storeName}
                    </div>
                  </div>

                  <input
                    type="text"
                    value={transferRef}
                    onChange={(e) => setTransferRef(e.target.value)}
                    placeholder="No. Referensi / Catatan Transfer (Opsional)"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
              )}
            </div>

            {/* Total Summary & Checkout Button */}
            <div className="p-4 bg-slate-950 border-t border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
                    Total Pembayaran
                  </div>
                  <div className="text-xl font-extrabold text-white font-mono">
                    {formatRupiah(totalAmount)}
                  </div>
                </div>

                <div className="text-right text-xs text-slate-400">
                  <div>Kasir: {currentUser?.name || 'Kasir'}</div>
                  <div className="text-emerald-400 font-medium">● Siap Cetak & WA</div>
                </div>
              </div>

              <button
                type="button"
                onClick={handleCheckout}
                disabled={cart.length === 0 || (paymentMethod === 'tunai' && !isCashSufficient)}
                className="w-full py-3.5 px-4 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded-xl text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>PROSES & CETAK STRUK</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
