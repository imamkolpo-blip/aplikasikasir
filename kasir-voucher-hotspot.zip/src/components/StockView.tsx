import React, { useState, useMemo } from 'react';
import {
  Layers,
  Plus,
  Upload,
  CheckCircle,
  Clock,
  Trash2,
  Sparkles,
  FileText,
  AlertCircle,
  Database,
  Filter,
} from 'lucide-react';
import { VoucherPackage, HotspotVoucher, StoreSettings } from '../types';
import {
  getVoucherStock,
  saveVoucherStock,
  addVoucherBatch,
} from '../services/storage';
import {
  parseBulkStockText,
  generateVoucherCredentials,
} from '../services/voucherGenerator';

interface StockViewProps {
  packages: VoucherPackage[];
  settings: StoreSettings;
  onStockUpdated: () => void;
}

export const StockView: React.FC<StockViewProps> = ({
  packages,
  settings,
  onStockUpdated,
}) => {
  const [stockList, setStockList] = useState<HotspotVoucher[]>(() => getVoucherStock());
  const [selectedPackageId, setSelectedPackageId] = useState<string>(
    packages[0]?.id || ''
  );
  const [activeTab, setActiveTab] = useState<'import' | 'generate' | 'list'>('import');

  // Bulk import state
  const [importText, setImportText] = useState('');
  const [importSuccessMsg, setImportSuccessMsg] = useState('');

  // Batch auto-generator state
  const [genCount, setGenCount] = useState<number>(20);
  const [genPrefix, setGenPrefix] = useState<string>('HS');

  // List filter state
  const [listStatus, setListStatus] = useState<'unused' | 'used' | 'all'>('unused');

  // Refresh stock
  const refresh = () => {
    const fresh = getVoucherStock();
    setStockList(fresh);
    onStockUpdated();
  };

  // Stock counts per package
  const stockCounts = useMemo(() => {
    const counts: Record<string, { total: number; unused: number; used: number }> = {};
    packages.forEach((pkg) => {
      const items = stockList.filter((v) => v.packageId === pkg.id);
      counts[pkg.id] = {
        total: items.length,
        unused: items.filter((v) => !v.isUsed).length,
        used: items.filter((v) => v.isUsed).length,
      };
    });
    return counts;
  }, [stockList, packages]);

  // Handle Bulk Import Text
  const handleImport = () => {
    if (!importText.trim()) return;

    const targetPkg = packages.find((p) => p.id === selectedPackageId);
    if (!targetPkg) return;

    const parsed = parseBulkStockText(importText, targetPkg.id, targetPkg.name);
    if (parsed.length === 0) {
      alert('Tidak ada voucher valid yang dapat dibaca. Format: user password atau user,password per baris.');
      return;
    }

    addVoucherBatch(parsed);
    setImportText('');
    setImportSuccessMsg(`Berhasil mengimpor ${parsed.length} voucher untuk paket ${targetPkg.name}!`);
    setTimeout(() => setImportSuccessMsg(''), 4000);
    refresh();
  };

  // Handle Batch Auto-Generation
  const handleGenerateBatch = () => {
    const targetPkg = packages.find((p) => p.id === selectedPackageId);
    if (!targetPkg) return;

    const batch: HotspotVoucher[] = [];
    const now = new Date().toISOString();
    const customSettings: StoreSettings = {
      ...settings,
      voucherFormatPrefix: genPrefix || settings.voucherFormatPrefix,
    };

    for (let i = 0; i < genCount; i++) {
      const creds = generateVoucherCredentials(customSettings, targetPkg.duration);
      batch.push({
        id: `vch-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        packageId: targetPkg.id,
        packageName: targetPkg.name,
        username: creds.username,
        password: creds.password,
        isUsed: false,
        createdAt: now,
      });
    }

    addVoucherBatch(batch);
    setImportSuccessMsg(`Berhasil men-generate ${batch.length} voucher baru untuk ${targetPkg.name}!`);
    setTimeout(() => setImportSuccessMsg(''), 4000);
    refresh();
  };

  // Clear Used Vouchers
  const handleCleanUsed = () => {
    if (confirm('Bersihkan semua voucher yang sudah terpakai dari daftar stok?')) {
      const remaining = stockList.filter((v) => !v.isUsed);
      saveVoucherStock(remaining);
      refresh();
    }
  };

  // Clear All Stock
  const handleClearAllStock = () => {
    if (confirm('PERINGATAN: Kosongkan SEMUA stok voucher?')) {
      saveVoucherStock([]);
      refresh();
    }
  };

  // Filtered list
  const filteredList = useMemo(() => {
    return stockList.filter((v) => {
      if (selectedPackageId && v.packageId !== selectedPackageId) return false;
      if (listStatus === 'unused' && v.isUsed) return false;
      if (listStatus === 'used' && !v.isUsed) return false;
      return true;
    });
  }, [stockList, selectedPackageId, listStatus]);

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 pb-24 md:pb-8 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-100 flex items-center gap-2">
            <span>Manajemen Stok Voucher Hotspot</span>
          </h2>
          <p className="text-xs text-slate-400">
            Impor voucher dari MikroTik / Mikhmon atau buat batch voucher dengan format User & Password
          </p>
        </div>

        <div className="flex items-center gap-2">
          {stockList.some((v) => v.isUsed) && (
            <button
              onClick={handleCleanUsed}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition-colors"
            >
              Hapus Voucher Terpakai
            </button>
          )}

          {stockList.length > 0 && (
            <button
              onClick={handleClearAllStock}
              className="px-3 py-2 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 rounded-xl text-xs font-semibold border border-rose-800/60 transition-colors"
            >
              Reset Stok
            </button>
          )}
        </div>
      </div>

      {/* Stock Cards by Package */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
        {packages.map((pkg) => {
          const stats = stockCounts[pkg.id] || { total: 0, unused: 0, used: 0 };
          const isSelected = selectedPackageId === pkg.id;

          return (
            <button
              key={pkg.id}
              onClick={() => setSelectedPackageId(pkg.id)}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                isSelected
                  ? 'bg-blue-950/60 border-blue-500 ring-1 ring-blue-500/50'
                  : 'bg-slate-900 hover:bg-slate-850 border-slate-800'
              }`}
            >
              <div className="text-[10px] text-slate-400 font-semibold truncate">
                {pkg.name}
              </div>
              <div className="text-lg font-extrabold text-white font-mono my-1">
                {stats.unused}
                <span className="text-[10px] text-slate-400 font-normal ml-1">tersedia</span>
              </div>
              <div className="text-[10px] text-slate-500 flex justify-between">
                <span>Durasi: {pkg.duration}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Action Tabs: Import vs Generator vs List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="flex border-b border-slate-800 bg-slate-950/60 p-2 gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('import')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0 ${
              activeTab === 'import'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>Impor dari MikroTik / Mikhmon (Paste Teks)</span>
          </button>

          <button
            onClick={() => setActiveTab('generate')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0 ${
              activeTab === 'generate'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Auto-Generate Batch</span>
          </button>

          <button
            onClick={() => setActiveTab('list')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0 ${
              activeTab === 'list'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Daftar Voucher Tersimpan ({stockList.length})</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-4 sm:p-6">
          {importSuccessMsg && (
            <div className="mb-4 p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{importSuccessMsg}</span>
            </div>
          )}

          {/* TAB 1: BULK IMPORT */}
          {activeTab === 'import' && (
            <div className="space-y-4 max-w-2xl">
              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  1. Pilih Paket Tujuan Voucher
                </label>
                <select
                  value={selectedPackageId}
                  onChange={(e) => setSelectedPackageId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                >
                  {packages.map((pkg) => (
                    <option key={pkg.id} value={pkg.id}>
                      {pkg.name} - Durasi: {pkg.duration} (Harga: Rp {pkg.price.toLocaleString('id-ID')})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  2. Paste List User & Password
                </label>
                <p className="text-[11px] text-slate-400 mb-2">
                  Format per baris: <code className="text-blue-400">username password</code> atau{' '}
                  <code className="text-blue-400">username,password</code> (Bisa langsung copy-paste dari export Mikhmon / User Manager / CSV).
                </p>
                <textarea
                  rows={8}
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder={`Contoh:\nhotspot01 1234\nhotspot02 5678\nhotspot03,9988\nuser4 4444`}
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500"
                />
              </div>

              <button
                onClick={handleImport}
                disabled={!importText.trim()}
                className="py-2.5 px-5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-xs font-bold rounded-xl shadow transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Simpan Voucher ke Stok</span>
              </button>
            </div>
          )}

          {/* TAB 2: AUTO-GENERATE BATCH */}
          {activeTab === 'generate' && (
            <div className="space-y-4 max-w-xl">
              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  Paket Voucher Target
                </label>
                <select
                  value={selectedPackageId}
                  onChange={(e) => setSelectedPackageId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                >
                  {packages.map((pkg) => (
                    <option key={pkg.id} value={pkg.id}>
                      {pkg.name} - Durasi: {pkg.duration}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Jumlah Voucher Dibuat
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={500}
                    value={genCount}
                    onChange={(e) => setGenCount(parseInt(e.target.value) || 10)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Awalan Kode (Prefix)
                  </label>
                  <input
                    type="text"
                    value={genPrefix}
                    onChange={(e) => setGenPrefix(e.target.value)}
                    placeholder="Contoh: HS"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <button
                onClick={handleGenerateBatch}
                className="py-2.5 px-5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Generate {genCount} Voucher Sekarang</span>
              </button>
            </div>
          )}

          {/* TAB 3: STOCK LIST */}
          {activeTab === 'list' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                  <button
                    onClick={() => setListStatus('unused')}
                    className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
                      listStatus === 'unused' ? 'bg-blue-600 text-white' : 'text-slate-400'
                    }`}
                  >
                    Belum Terpakai
                  </button>
                  <button
                    onClick={() => setListStatus('used')}
                    className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
                      listStatus === 'used' ? 'bg-blue-600 text-white' : 'text-slate-400'
                    }`}
                  >
                    Sudah Terpakai
                  </button>
                  <button
                    onClick={() => setListStatus('all')}
                    className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
                      listStatus === 'all' ? 'bg-blue-600 text-white' : 'text-slate-400'
                    }`}
                  >
                    Semua ({stockList.length})
                  </button>
                </div>

                <div className="text-xs text-slate-400">
                  Menampilkan {filteredList.length} voucher
                </div>
              </div>

              {filteredList.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-xs">
                  Tidak ada voucher dengan filter ini.
                </div>
              ) : (
                <div className="max-h-96 overflow-y-auto rounded-xl border border-slate-800">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-slate-950 text-slate-400 sticky top-0 border-b border-slate-800">
                      <tr>
                        <th className="p-2.5">No</th>
                        <th className="p-2.5">Paket</th>
                        <th className="p-2.5">Username</th>
                        <th className="p-2.5">Password</th>
                        <th className="p-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {filteredList.map((v, i) => (
                        <tr key={v.id} className="hover:bg-slate-850/50">
                          <td className="p-2.5 text-slate-500">{i + 1}</td>
                          <td className="p-2.5 text-slate-300 font-sans">{v.packageName}</td>
                          <td className="p-2.5 font-bold text-blue-400">{v.username}</td>
                          <td className="p-2.5 font-bold text-slate-200">{v.password}</td>
                          <td className="p-2.5">
                            {v.isUsed ? (
                              <span className="text-[10px] text-slate-500 bg-slate-800 px-2 py-0.5 rounded">
                                Terpakai
                              </span>
                            ) : (
                              <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.5 rounded">
                                Tersedia
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
