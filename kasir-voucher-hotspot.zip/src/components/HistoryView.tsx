import React, { useState, useMemo } from 'react';
import {
  Search,
  Calendar,
  Filter,
  Download,
  Printer,
  Share2,
  Trash2,
  Receipt,
  ArrowUpDown,
  CreditCard,
  Wallet,
  Clock,
  ExternalLink,
  DollarSign,
  Layers,
  ChevronRight,
} from 'lucide-react';
import { Transaction, StoreSettings } from '../types';
import { formatRupiah, formatDateTime, generateWhatsAppUrl } from '../services/receiptFormatter';
import { deleteTransaction, clearAllTransactions } from '../services/storage';

interface HistoryViewProps {
  transactions: Transaction[];
  settings: StoreSettings;
  onRefreshTransactions: () => void;
  onSelectTransaction: (trx: Transaction) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  transactions,
  settings,
  onRefreshTransactions,
  onSelectTransaction,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPeriod, setFilterPeriod] = useState<'today' | 'week' | 'month' | 'all'>('today');
  const [filterMethod, setFilterMethod] = useState<'all' | 'tunai' | 'transfer'>('all');

  // Filter logic
  const filteredTransactions = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const sevenDaysAgo = startOfToday - 7 * 24 * 60 * 60 * 1000;
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();

    return transactions.filter((trx) => {
      const trxTime = new Date(trx.createdAt).getTime();

      // Period filter
      if (filterPeriod === 'today' && trxTime < startOfToday) return false;
      if (filterPeriod === 'week' && trxTime < sevenDaysAgo) return false;
      if (filterPeriod === 'month' && trxTime < startOfMonth) return false;

      // Method filter
      if (filterMethod !== 'all' && trx.paymentMethod !== filterMethod) return false;

      // Search term
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchesId = trx.id.toLowerCase().includes(query);
        const matchesCustomer = trx.customerName?.toLowerCase().includes(query) || false;
        const matchesVouchers = trx.items.some((item) =>
          item.vouchers.some(
            (v) =>
              v.username.toLowerCase().includes(query) ||
              v.password.toLowerCase().includes(query)
          )
        );
        return matchesId || matchesCustomer || matchesVouchers;
      }

      return true;
    });
  }, [transactions, filterPeriod, filterMethod, searchTerm]);

  // Aggregate stats
  const stats = useMemo(() => {
    let totalOmset = 0;
    let totalTunai = 0;
    let totalTransfer = 0;
    let totalVouchers = 0;

    filteredTransactions.forEach((trx) => {
      totalOmset += trx.totalAmount;
      if (trx.paymentMethod === 'tunai') {
        totalTunai += trx.totalAmount;
      } else {
        totalTransfer += trx.totalAmount;
      }
      trx.items.forEach((item) => {
        totalVouchers += item.quantity;
      });
    });

    return {
      totalOmset,
      totalTunai,
      totalTransfer,
      totalTransactions: filteredTransactions.length,
      totalVouchers,
    };
  }, [filteredTransactions]);

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(`Yakin ingin menghapus transaksi ${id}?`)) {
      deleteTransaction(id);
      onRefreshTransactions();
    }
  };

  const handleClearAll = () => {
    if (confirm('PERINGATAN: Apakah Anda yakin ingin mengosongkan SEMUA riwayat transaksi? Tindakan ini tidak dapat dibatalkan.')) {
      clearAllTransactions();
      onRefreshTransactions();
    }
  };

  const handleExportCSV = () => {
    if (filteredTransactions.length === 0) {
      alert('Tidak ada transaksi untuk diekspor!');
      return;
    }

    const headers = [
      'No. Transaksi',
      'Tanggal & Waktu',
      'Kasir',
      'Pelanggan',
      'No. HP',
      'Metode Bayar',
      'Total (Rp)',
      'Paket Voucher',
      'Akun (User:Pass)',
    ];

    const rows = filteredTransactions.map((t) => [
      t.id,
      formatDateTime(t.createdAt),
      t.cashierName,
      t.customerName || '-',
      t.customerPhone || '-',
      t.paymentMethod.toUpperCase(),
      t.totalAmount,
      t.items.map((i) => `${i.packageName} (x${i.quantity})`).join('; '),
      t.items
        .flatMap((i) => i.vouchers.map((v) => `${v.username}:${v.password}`))
        .join('; '),
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.map((x) => `"${x}"`).join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Laporan-Kasir-Hotspot-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 pb-24 md:pb-8 space-y-5">
      {/* Top Banner & Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-100 flex items-center gap-2">
            <span>Riwayat Transaksi & Laporan</span>
          </h2>
          <p className="text-xs text-slate-400">
            Daftar penjualan voucher, cetak ulang struk, dan rekap keuangan
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor CSV</span>
          </button>

          {transactions.length > 0 && (
            <button
              onClick={handleClearAll}
              className="flex items-center gap-1.5 px-3 py-2 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 rounded-xl text-xs font-semibold border border-rose-800/60 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus Semua</span>
            </button>
          )}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total Omset */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Total Omset</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-emerald-400 font-mono">
            {formatRupiah(stats.totalOmset)}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            {stats.totalTransactions} Transaksi Terpilih
          </div>
        </div>

        {/* Total Tunai */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Bayar Tunai</span>
            <div className="w-7 h-7 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-blue-400 font-mono">
            {formatRupiah(stats.totalTunai)}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Uang Tunai di Laci</div>
        </div>

        {/* Total Transfer */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Bayar Transfer</span>
            <div className="w-7 h-7 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-purple-400 font-mono">
            {formatRupiah(stats.totalTransfer)}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Masuk Rekening / QRIS</div>
        </div>

        {/* Total Voucher */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Voucher Terjual</span>
            <div className="w-7 h-7 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-amber-400 font-mono">
            {stats.totalVouchers} <span className="text-xs font-normal text-slate-400">pcs</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Akun Hotspot Aktif</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search Input */}
          <div className="md:col-span-5 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari ID transaksi, nama, user, atau password voucher..."
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Period Filter Tabs */}
          <div className="md:col-span-4 flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
            {[
              { id: 'today', label: 'Hari Ini' },
              { id: 'week', label: '7 Hari' },
              { id: 'month', label: 'Bulan Ini' },
              { id: 'all', label: 'Semua' },
            ].map((p) => (
              <button
                key={p.id}
                onClick={() => setFilterPeriod(p.id as any)}
                className={`flex-1 py-1.5 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${
                  filterPeriod === p.id
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Payment Method Filter */}
          <div className="md:col-span-3 flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
            {[
              { id: 'all', label: 'Semua Bayar' },
              { id: 'tunai', label: 'Tunai' },
              { id: 'transfer', label: 'Transfer' },
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => setFilterMethod(m.id as any)}
                className={`flex-1 py-1.5 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${
                  filterMethod === m.id
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Transactions List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        {filteredTransactions.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <Receipt className="w-10 h-10 mx-auto mb-2 opacity-30 text-slate-400" />
            <p className="text-sm font-semibold text-slate-400">Tidak ada transaksi ditemukan</p>
            <p className="text-xs text-slate-600 mt-1">
              Sesuaikan filter tanggal atau lakukan penjualan pertama di menu Kasir.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {filteredTransactions.map((trx) => (
              <div
                key={trx.id}
                onClick={() => onSelectTransaction(trx)}
                className="p-4 hover:bg-slate-850/60 transition-colors cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-3 group"
              >
                {/* Left Info */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-blue-400">
                      {trx.id}
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        trx.paymentMethod === 'tunai'
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/60'
                          : 'bg-purple-950/60 text-purple-400 border border-purple-800/60'
                      }`}
                    >
                      {trx.paymentMethod.toUpperCase()}
                    </span>
                    {trx.customerName && (
                      <span className="text-xs text-slate-300 font-medium">
                        · {trx.customerName}
                      </span>
                    )}
                  </div>

                  <div className="text-xs text-slate-300 font-medium">
                    {trx.items.map((item) => `${item.packageName} (x${item.quantity})`).join(', ')}
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-slate-500 font-mono">
                    <span>{formatDateTime(trx.createdAt)}</span>
                    <span>·</span>
                    <span>Kasir: {trx.cashierName}</span>
                  </div>
                </div>

                {/* Right Info: Total & Actions */}
                <div className="flex items-center justify-between md:justify-end gap-4 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-800/50">
                  <div className="text-left md:text-right">
                    <div className="text-sm font-extrabold text-emerald-400 font-mono">
                      {formatRupiah(trx.totalAmount)}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {trx.items.reduce((s, i) => s + i.quantity, 0)} Voucher
                    </div>
                  </div>

                  {/* Quick Action Buttons */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectTransaction(trx);
                      }}
                      className="p-2 bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-300 rounded-lg text-xs transition-colors"
                      title="Buka Struk"
                    >
                      <Receipt className="w-4 h-4" />
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        const url = generateWhatsAppUrl(trx, settings);
                        window.open(url, '_blank');
                      }}
                      className="p-2 bg-slate-800 hover:bg-emerald-600 hover:text-white text-slate-300 rounded-lg text-xs transition-colors"
                      title="Kirim Struk ke WhatsApp"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={(e) => handleDelete(trx.id, e)}
                      className="p-2 bg-slate-800 hover:bg-rose-600 hover:text-white text-slate-400 rounded-lg text-xs transition-colors"
                      title="Hapus Transaksi"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <div className="text-slate-600 group-hover:text-slate-300 transition-colors ml-1 hidden sm:block">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
