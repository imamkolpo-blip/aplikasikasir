import React, { useState } from 'react';
import { Lock, User, KeyRound, Eye, EyeOff, ShieldCheck, Wifi } from 'lucide-react';
import { CashierUser } from '../types';
import { verifyLogin } from '../services/storage';

interface LoginModalProps {
  onLoginSuccess: (user: CashierUser) => void;
  storeName: string;
}

export const LoginModal: React.FC<LoginModalProps> = ({ onLoginSuccess, storeName }) => {
  const [username, setUsername] = useState('kasir');
  const [password, setPassword] = useState('123456');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!username.trim() || !password.trim()) {
      setErrorMsg('Harap isi Username dan Password.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const user = verifyLogin(username, password);
      if (user) {
        onLoginSuccess(user);
      } else {
        setErrorMsg('Username atau Password salah! Periksa kembali.');
      }
      setIsLoading(false);
    }, 200);
  };

  const setPreset = (u: string, p: string) => {
    setUsername(u);
    setPassword(p);
    setErrorMsg('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        {/* Header Banner */}
        <div className="bg-gradient-to-br from-blue-700 via-blue-600 to-indigo-800 p-6 text-center text-white relative">
          <div className="w-14 h-14 mx-auto mb-3 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md border border-white/20 shadow-inner">
            <Wifi className="w-8 h-8 text-white animate-pulse" />
          </div>
          <h2 className="text-xl font-bold tracking-tight">{storeName || 'KASIR HOTSPOT'}</h2>
          <p className="text-xs text-blue-100/90 mt-1">
            Masuk untuk mengakses sistem penjualan voucher
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-400 text-xs flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Username Kasir
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Masukkan username kasir..."
                autoComplete="username"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 text-sm placeholder-slate-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                autoFocus
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <KeyRound className="w-4 h-4" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Masukkan password..."
                autoComplete="current-password"
                className="w-full pl-10 pr-10 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 text-sm placeholder-slate-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 hover:text-slate-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 disabled:opacity-50 text-white font-semibold rounded-xl text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Lock className="w-4 h-4" />
            <span>{isLoading ? 'Memeriksa...' : 'Buka Kasir'}</span>
          </button>

          {/* Quick preset account hints */}
          <div className="pt-2 border-t border-slate-800/80">
            <p className="text-[11px] text-slate-400 mb-2 font-medium">
              Akun Kasir Bawaan (Klik untuk mengisi cepat):
            </p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setPreset('kasir', '123456')}
                className="p-2 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-left transition-colors"
              >
                <div className="font-semibold text-slate-200">Kasir</div>
                <div className="text-[10px] text-slate-500 font-mono">User: kasir | Pass: 123456</div>
              </button>

              <button
                type="button"
                onClick={() => setPreset('admin', 'admin123')}
                className="p-2 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-left transition-colors"
              >
                <div className="font-semibold text-slate-200">Admin</div>
                <div className="text-[10px] text-slate-500 font-mono">User: admin | Pass: admin123</div>
              </button>
            </div>
          </div>

          <div className="text-center text-[11px] text-slate-500 flex items-center justify-center gap-1.5 pt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            <span>Mode Kasir Offline Terenkripsi Lokal</span>
          </div>
        </form>
      </div>
    </div>
  );
};
