import { StoreSettings, HotspotVoucher } from '../types';

/**
 * Characters that avoid ambiguous glyphs like 0/O and 1/I/l
 */
const CHARS_LETTERS = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const CHARS_DIGITS = '23456789';
const CHARS_ALPHANUMERIC = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';

function getRandomString(length: number, charset: string = CHARS_ALPHANUMERIC): string {
  let result = '';
  for (let i = 0; i < length; i++) {
    result += charset.charAt(Math.floor(Math.random() * charset.length));
  }
  return result;
}

export function generateVoucherCredentials(
  settings: StoreSettings,
  packageDuration?: string
): { username: string; password: string } {
  const prefix = settings.voucherFormatPrefix ? `${settings.voucherFormatPrefix}-` : '';
  const uLength = Math.max(3, settings.voucherUsernameLength || 5);
  const pLength = Math.max(3, settings.voucherPasswordLength || 4);

  // Clean prefix if duration hint helps (e.g. HS-5J-8492)
  const code = getRandomString(uLength, CHARS_ALPHANUMERIC);
  const username = `${prefix}${code}`.toLowerCase();

  if (settings.sameUserPass) {
    return {
      username,
      password: username,
    };
  }

  const password = getRandomString(pLength, CHARS_DIGITS);
  return {
    username,
    password,
  };
}

/**
 * Generate a unique transaction receipt ID: TRX-YYYYMMDD-HHMMSS-XXX
 */
export function generateTransactionId(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const h = String(now.getHours()).padStart(2, '0');
  const min = String(now.getMinutes()).padStart(2, '0');
  const sec = String(now.getSeconds()).padStart(2, '0');
  const rand = Math.floor(100 + Math.random() * 900);
  return `TRX-${y}${m}${d}-${h}${min}${sec}-${rand}`;
}

/**
 * Parse bulk text input (from Mikhmon, Mikrotik script, or spreadsheet)
 * Accepted formats:
 * username password
 * username,password
 * username|password
 * username;password
 */
export function parseBulkStockText(
  rawText: string,
  packageId: string,
  packageName: string
): HotspotVoucher[] {
  const lines = rawText.split(/\r?\n/);
  const vouchers: HotspotVoucher[] = [];
  const now = new Date().toISOString();

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;

    // split by comma, tab, semicolon, pipe or space
    const parts = trimmed.split(/[\t,;| ]+/).filter(Boolean);
    if (parts.length >= 2) {
      vouchers.push({
        id: `vch-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        packageId,
        packageName,
        username: parts[0],
        password: parts[1],
        isUsed: false,
        createdAt: now,
      });
    } else if (parts.length === 1) {
      // same username and password
      vouchers.push({
        id: `vch-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        packageId,
        packageName,
        username: parts[0],
        password: parts[0],
        isUsed: false,
        createdAt: now,
      });
    }
  }

  return vouchers;
}
