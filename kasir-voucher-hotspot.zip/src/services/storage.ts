import {
  VoucherPackage,
  StoreSettings,
  Transaction,
  HotspotVoucher,
  CashierUser,
} from '../types';
import {
  DEFAULT_VOUCHER_PACKAGES,
  DEFAULT_SETTINGS,
  DEFAULT_USERS,
} from '../constants/initialData';

const STORAGE_KEYS = {
  PACKAGES: 'khp_voucher_packages_v1',
  SETTINGS: 'khp_store_settings_v1',
  TRANSACTIONS: 'khp_transactions_v1',
  STOCK: 'khp_voucher_stock_v1',
  USERS: 'khp_cashier_users_v1',
  CURRENT_USER: 'khp_current_user_v1',
};

// --- PACKAGES ---
export function getVoucherPackages(): VoucherPackage[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PACKAGES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.PACKAGES, JSON.stringify(DEFAULT_VOUCHER_PACKAGES));
      return DEFAULT_VOUCHER_PACKAGES;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error loading voucher packages:', err);
    return DEFAULT_VOUCHER_PACKAGES;
  }
}

export function saveVoucherPackages(packages: VoucherPackage[]): void {
  localStorage.setItem(STORAGE_KEYS.PACKAGES, JSON.stringify(packages));
}

export function resetVoucherPackages(): VoucherPackage[] {
  localStorage.setItem(STORAGE_KEYS.PACKAGES, JSON.stringify(DEFAULT_VOUCHER_PACKAGES));
  return DEFAULT_VOUCHER_PACKAGES;
}

// --- SETTINGS ---
export function getStoreSettings(): StoreSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
      return DEFAULT_SETTINGS;
    }
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (err) {
    console.error('Error loading store settings:', err);
    return DEFAULT_SETTINGS;
  }
}

export function saveStoreSettings(settings: StoreSettings): void {
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
}

// --- USERS & AUTH ---
export function getUsers(): CashierUser[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(DEFAULT_USERS));
      return DEFAULT_USERS;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error loading users:', err);
    return DEFAULT_USERS;
  }
}

export function saveUsers(users: CashierUser[]): void {
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
}

export function getCurrentUser(): CashierUser | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function setCurrentUser(user: CashierUser | null): void {
  if (user) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  }
}

export function verifyLogin(usernameInput: string, passwordInput: string): CashierUser | null {
  const users = getUsers();
  const trimmedUser = usernameInput.trim().toLowerCase();
  const user = users.find(
    (u) => u.username.toLowerCase() === trimmedUser && u.passwordHash === passwordInput
  );
  return user || null;
}

// --- TRANSACTIONS ---
export function getTransactions(): Transaction[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (!raw) return [];
    const list: Transaction[] = JSON.parse(raw);
    // Sort descending by date
    return list.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  } catch (err) {
    console.error('Error loading transactions:', err);
    return [];
  }
}

export function saveTransaction(trx: Transaction): void {
  const list = getTransactions();
  list.unshift(trx);
  localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(list));
}

export function deleteTransaction(id: string): void {
  const list = getTransactions().filter((t) => t.id !== id);
  localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(list));
}

export function clearAllTransactions(): void {
  localStorage.removeItem(STORAGE_KEYS.TRANSACTIONS);
}

// --- VOUCHER STOCK ---
export function getVoucherStock(): HotspotVoucher[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.STOCK);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error loading voucher stock:', err);
    return [];
  }
}

export function saveVoucherStock(stock: HotspotVoucher[]): void {
  localStorage.setItem(STORAGE_KEYS.STOCK, JSON.stringify(stock));
}

export function addVoucherBatch(vouchers: HotspotVoucher[]): void {
  const current = getVoucherStock();
  const updated = [...vouchers, ...current];
  saveVoucherStock(updated);
}

export function consumeVoucherFromStock(
  packageId: string,
  quantity: number
): Array<{ username: string; password: string }> {
  const stock = getVoucherStock();
  const consumed: Array<{ username: string; password: string }> = [];

  for (let i = 0; i < stock.length && consumed.length < quantity; i++) {
    if (stock[i].packageId === packageId && !stock[i].isUsed) {
      stock[i].isUsed = true;
      stock[i].usedAt = new Date().toISOString();
      consumed.push({
        username: stock[i].username,
        password: stock[i].password,
      });
    }
  }

  saveVoucherStock(stock);
  return consumed;
}

// --- BACKUP & RESTORE ---
export function exportDatabaseBackup(): string {
  const data = {
    exportedAt: new Date().toISOString(),
    version: '1.0',
    packages: getVoucherPackages(),
    settings: getStoreSettings(),
    transactions: getTransactions(),
    stock: getVoucherStock(),
    users: getUsers(),
  };
  return JSON.stringify(data, null, 2);
}

export function importDatabaseBackup(jsonString: string): { success: boolean; message: string } {
  try {
    const data = JSON.parse(jsonString);
    if (data.packages && Array.isArray(data.packages)) {
      saveVoucherPackages(data.packages);
    }
    if (data.settings && typeof data.settings === 'object') {
      saveStoreSettings(data.settings);
    }
    if (data.transactions && Array.isArray(data.transactions)) {
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(data.transactions));
    }
    if (data.stock && Array.isArray(data.stock)) {
      saveVoucherStock(data.stock);
    }
    if (data.users && Array.isArray(data.users)) {
      saveUsers(data.users);
    }
    return { success: true, message: 'Data cadangan berhasil dipulihkan!' };
  } catch (err) {
    return { success: false, message: 'Format file tidak valid atau rusak.' };
  }
}
