import { Transaction, StoreSettings } from '../types';

export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDateTime(isoString: string): string {
  try {
    const date = new Date(isoString);
    return new Intl.DateTimeFormat('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  } catch {
    return isoString;
  }
}

/**
 * Format receipt into a professional WhatsApp text message
 */
export function buildWhatsAppMessage(transaction: Transaction, settings: StoreSettings): string {
  const dateFormatted = formatDateTime(transaction.createdAt);
  const paymentBadge = transaction.paymentMethod === 'tunai' ? '💵 TUNAI (CASH)' : '💳 TRANSFER / NON-TUNAI';

  let msg = `*=================================*\n`;
  msg += `*${settings.storeName.toUpperCase()}*\n`;
  if (settings.tagline) msg += `_${settings.tagline}_\n`;
  msg += `*=================================*\n\n`;

  msg += `📄 *STRUK BUKTI PEMBELIAN VOUCHER*\n`;
  msg += `No. Transaksi : \`${transaction.id}\`\n`;
  msg += `Tanggal/Waktu : ${dateFormatted}\n`;
  msg += `Kasir         : ${transaction.cashierName}\n`;
  if (transaction.customerName) {
    msg += `Pelanggan     : ${transaction.customerName}\n`;
  }
  msg += `Metode Bayar  : ${paymentBadge}\n\n`;

  msg += `*---------------------------------*\n`;
  msg += `*DETAIL VOUCHER HOTSPOT:*\n`;
  msg += `*---------------------------------*\n`;

  transaction.items.forEach((item, index) => {
    msg += `\n📦 *Paket ${index + 1}: ${item.packageName}*\n`;
    msg += `Durasi    : *${item.duration}*\n`;
    msg += `Jumlah    : ${item.quantity} Voucher\n`;
    msg += `Subtotal  : ${formatRupiah(item.price * item.quantity)}\n`;
    msg += `*AKUN LOGIN HOTSPOT:*\n`;

    item.vouchers.forEach((vch, vIndex) => {
      msg += `  ${vIndex + 1}. *USER*     : \`${vch.username}\`\n`;
      msg += `     *PASSWORD* : \`${vch.password}\`\n`;
    });
  });

  msg += `\n*---------------------------------*\n`;
  msg += `*TOTAL PEMBAYARAN: ${formatRupiah(transaction.totalAmount)}*\n`;

  if (transaction.paymentMethod === 'tunai' && transaction.paymentDetail?.cashReceived) {
    msg += `Bayar Tunai : ${formatRupiah(transaction.paymentDetail.cashReceived)}\n`;
    msg += `Kembalian   : ${formatRupiah(transaction.paymentDetail.cashChange || 0)}\n`;
  } else if (transaction.paymentMethod === 'transfer' && transaction.paymentDetail?.transferBank) {
    msg += `Bank/E-Wallet: ${transaction.paymentDetail.transferBank}\n`;
    if (transaction.paymentDetail.transferRef) {
      msg += `Ref/Catatan : ${transaction.paymentDetail.transferRef}\n`;
    }
  }

  msg += `*---------------------------------*\n\n`;

  msg += `📶 *CARA MENGGUNAKAN HOTSPOT:*\n`;
  msg += `1. Sambungkan WiFi ke: *${settings.wifiSsid}*\n`;
  msg += `2. Buka browser, kunjungi: *${settings.hotspotLoginUrl}*\n`;
  msg += `3. Masukkan *Username* dan *Password* di atas.\n`;
  msg += `4. Klik *LOGIN / CONNECT* & nikmati internetnya!\n\n`;

  if (settings.phone) {
    msg += `📞 Bantuan / CS: ${settings.phone}\n`;
  }
  msg += `_${settings.footerMessage}_\n`;
  msg += `*=================================*`;

  return msg;
}

/**
 * Generate WhatsApp URL (with optional recipient phone number)
 */
export function generateWhatsAppUrl(
  transaction: Transaction,
  settings: StoreSettings,
  phoneOverride?: string
): string {
  const message = buildWhatsAppMessage(transaction, settings);
  let rawPhone = phoneOverride || transaction.customerPhone || '';

  // Clean phone number: replace non-digits
  let cleanPhone = rawPhone.replace(/\D/g, '');
  if (cleanPhone.startsWith('0')) {
    cleanPhone = '62' + cleanPhone.substring(1);
  } else if (cleanPhone.startsWith('8')) {
    cleanPhone = '62' + cleanPhone;
  }

  const encodedText = encodeURIComponent(message);
  if (cleanPhone && cleanPhone.length >= 9) {
    return `https://wa.me/${cleanPhone}?text=${encodedText}`;
  }
  return `https://wa.me/?text=${encodedText}`;
}

/**
 * Build plain text receipt for printing or copy
 */
export function buildPlainTextReceipt(transaction: Transaction, settings: StoreSettings): string {
  const line = '----------------------------------------';
  const doubleLine = '========================================';
  let out = '';

  out += `${settings.storeName}\n`;
  if (settings.tagline) out += `${settings.tagline}\n`;
  if (settings.address) out += `${settings.address}\n`;
  if (settings.phone) out += `Telp/WA: ${settings.phone}\n`;
  out += `${doubleLine}\n`;

  out += `No. Transaksi : ${transaction.id}\n`;
  out += `Tanggal       : ${formatDateTime(transaction.createdAt)}\n`;
  out += `Kasir         : ${transaction.cashierName}\n`;
  if (transaction.customerName) out += `Pelanggan     : ${transaction.customerName}\n`;
  out += `Pembayaran    : ${transaction.paymentMethod === 'tunai' ? 'TUNAI' : 'TRANSFER'}\n`;
  out += `${line}\n`;

  transaction.items.forEach((item) => {
    out += `${item.packageName} x${item.quantity}\n`;
    out += `  Subtotal: ${formatRupiah(item.price * item.quantity)}\n`;
    item.vouchers.forEach((v, idx) => {
      out += `  [#${idx + 1}] USER: ${v.username} | PASS: ${v.password}\n`;
    });
  });

  out += `${line}\n`;
  out += `TOTAL BAYAR   : ${formatRupiah(transaction.totalAmount)}\n`;

  if (transaction.paymentMethod === 'tunai' && transaction.paymentDetail?.cashReceived) {
    out += `Bayar Tunai   : ${formatRupiah(transaction.paymentDetail.cashReceived)}\n`;
    out += `Kembalian     : ${formatRupiah(transaction.paymentDetail.cashChange || 0)}\n`;
  }

  out += `${doubleLine}\n`;
  out += `WiFi SSID : ${settings.wifiSsid}\n`;
  out += `Login URL : ${settings.hotspotLoginUrl}\n`;
  out += `${settings.footerMessage}\n`;

  return out;
}
